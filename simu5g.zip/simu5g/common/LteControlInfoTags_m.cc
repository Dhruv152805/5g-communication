//
// Generated file, do not edit! Created by opp_msgtool 6.4 from simu5g/common/LteControlInfoTags.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#if defined(__clang__)
#  pragma clang diagnostic ignored "-Wshadow"
#  pragma clang diagnostic ignored "-Wconversion"
#  pragma clang diagnostic ignored "-Wunused-parameter"
#  pragma clang diagnostic ignored "-Wc++98-compat"
#  pragma clang diagnostic ignored "-Wunreachable-code-break"
#  pragma clang diagnostic ignored "-Wold-style-cast"
#elif defined(__GNUC__)
#  pragma GCC diagnostic ignored "-Wshadow"
#  pragma GCC diagnostic ignored "-Wconversion"
#  pragma GCC diagnostic ignored "-Wunused-parameter"
#  pragma GCC diagnostic ignored "-Wold-style-cast"
#  pragma GCC diagnostic ignored "-Wsuggest-attribute=noreturn"
#  pragma GCC diagnostic ignored "-Wfloat-conversion"
#endif

#include <iostream>
#include <sstream>
#include <memory>
#include <type_traits>
#include "LteControlInfoTags_m.h"

namespace omnetpp {

// Template pack/unpack rules. They are declared *after* a1l type-specific pack functions for multiple reasons.
// They are in the omnetpp namespace, to allow them to be found by argument-dependent lookup via the cCommBuffer argument

// Packing/unpacking an std::vector
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::vector<T,A>& v)
{
    int n = v.size();
    doParsimPacking(buffer, n);
    for (int i = 0; i < n; i++)
        doParsimPacking(buffer, v[i]);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::vector<T,A>& v)
{
    int n;
    doParsimUnpacking(buffer, n);
    v.resize(n);
    for (int i = 0; i < n; i++)
        doParsimUnpacking(buffer, v[i]);
}

// Packing/unpacking an std::list
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::list<T,A>& l)
{
    doParsimPacking(buffer, (int)l.size());
    for (typename std::list<T,A>::const_iterator it = l.begin(); it != l.end(); ++it)
        doParsimPacking(buffer, (T&)*it);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::list<T,A>& l)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        l.push_back(T());
        doParsimUnpacking(buffer, l.back());
    }
}

// Packing/unpacking an std::set
template<typename T, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::set<T,Tr,A>& s)
{
    doParsimPacking(buffer, (int)s.size());
    for (typename std::set<T,Tr,A>::const_iterator it = s.begin(); it != s.end(); ++it)
        doParsimPacking(buffer, *it);
}

template<typename T, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::set<T,Tr,A>& s)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        T x;
        doParsimUnpacking(buffer, x);
        s.insert(x);
    }
}

// Packing/unpacking an std::map
template<typename K, typename V, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::map<K,V,Tr,A>& m)
{
    doParsimPacking(buffer, (int)m.size());
    for (typename std::map<K,V,Tr,A>::const_iterator it = m.begin(); it != m.end(); ++it) {
        doParsimPacking(buffer, it->first);
        doParsimPacking(buffer, it->second);
    }
}

template<typename K, typename V, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::map<K,V,Tr,A>& m)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        K k; V v;
        doParsimUnpacking(buffer, k);
        doParsimUnpacking(buffer, v);
        m[k] = v;
    }
}

// Default pack/unpack function for arrays
template<typename T>
void doParsimArrayPacking(omnetpp::cCommBuffer *b, const T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimPacking(b, t[i]);
}

template<typename T>
void doParsimArrayUnpacking(omnetpp::cCommBuffer *b, T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimUnpacking(b, t[i]);
}

// Default rule to prevent compiler from choosing base class' doParsimPacking() function
template<typename T>
void doParsimPacking(omnetpp::cCommBuffer *, const T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimPacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

template<typename T>
void doParsimUnpacking(omnetpp::cCommBuffer *, T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimUnpacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

}  // namespace omnetpp


template<typename T>
std::string toStringIfPrintable(const T& t) {
    if constexpr (omnetpp::internal::is_printable<T>::value) {
        std::ostringstream os;
        os << t;
        return os.str();
    }
    return omnetpp::cClassDescriptor::UNPRINTABLE;
}

template<typename T>
bool fromStringIfExtractable(T& t, const char *s) {
    if constexpr (omnetpp::internal::is_extractable<T>::value) {
        std::istringstream is(s);
        is >> t;
        return true;
    }
    return false;
}

namespace simu5g {

Register_Class(IpFlowInd)

IpFlowInd::IpFlowInd() : ::inet::TagBase()
{
}

IpFlowInd::IpFlowInd(const IpFlowInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

IpFlowInd::~IpFlowInd()
{
}

IpFlowInd& IpFlowInd::operator=(const IpFlowInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void IpFlowInd::copy(const IpFlowInd& other)
{
    this->srcAddr = other.srcAddr;
    this->dstAddr = other.dstAddr;
    this->typeOfService = other.typeOfService;
}

void IpFlowInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->srcAddr);
    doParsimPacking(b,this->dstAddr);
    doParsimPacking(b,this->typeOfService);
}

void IpFlowInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->srcAddr);
    doParsimUnpacking(b,this->dstAddr);
    doParsimUnpacking(b,this->typeOfService);
}

const ::inet::Ipv4Address& IpFlowInd::getSrcAddr() const
{
    return this->srcAddr;
}

void IpFlowInd::setSrcAddr(const ::inet::Ipv4Address& srcAddr)
{
    this->srcAddr = srcAddr;
}

const ::inet::Ipv4Address& IpFlowInd::getDstAddr() const
{
    return this->dstAddr;
}

void IpFlowInd::setDstAddr(const ::inet::Ipv4Address& dstAddr)
{
    this->dstAddr = dstAddr;
}

uint16_t IpFlowInd::getTypeOfService() const
{
    return this->typeOfService;
}

void IpFlowInd::setTypeOfService(uint16_t typeOfService)
{
    this->typeOfService = typeOfService;
}

class IpFlowIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_srcAddr,
        FIELD_dstAddr,
        FIELD_typeOfService,
    };
  public:
    IpFlowIndDescriptor();
    virtual ~IpFlowIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(IpFlowIndDescriptor)

IpFlowIndDescriptor::IpFlowIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::IpFlowInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

IpFlowIndDescriptor::~IpFlowIndDescriptor()
{
    delete[] propertyNames;
}

bool IpFlowIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<IpFlowInd *>(obj)!=nullptr;
}

const char **IpFlowIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *IpFlowIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string IpFlowIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void IpFlowIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int IpFlowIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 3+base->getFieldCount() : 3;
}

unsigned int IpFlowIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        0,    // FIELD_srcAddr
        0,    // FIELD_dstAddr
        FD_ISEDITABLE,    // FIELD_typeOfService
    };
    return (field >= 0 && field < 3) ? fieldTypeFlags[field] : 0;
}

const char *IpFlowIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "srcAddr",
        "dstAddr",
        "typeOfService",
    };
    return (field >= 0 && field < 3) ? fieldNames[field] : nullptr;
}

int IpFlowIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "srcAddr") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "dstAddr") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "typeOfService") == 0) return baseIndex + 2;
    return base ? base->findField(fieldName) : -1;
}

const char *IpFlowIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "inet::Ipv4Address",    // FIELD_srcAddr
        "inet::Ipv4Address",    // FIELD_dstAddr
        "uint16",    // FIELD_typeOfService
    };
    return (field >= 0 && field < 3) ? fieldTypeStrings[field] : nullptr;
}

const char **IpFlowIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *IpFlowIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int IpFlowIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void IpFlowIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'IpFlowInd'", field);
    }
}

const char *IpFlowIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string IpFlowIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        case FIELD_srcAddr: return pp->getSrcAddr().str();
        case FIELD_dstAddr: return pp->getDstAddr().str();
        case FIELD_typeOfService: return ulong2string(pp->getTypeOfService());
        default: return "";
    }
}

void IpFlowIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        case FIELD_typeOfService: pp->setTypeOfService(string2ulong(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'IpFlowInd'", field);
    }
}

omnetpp::cValue IpFlowIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        case FIELD_srcAddr: return omnetpp::toAnyPtr(&pp->getSrcAddr()); break;
        case FIELD_dstAddr: return omnetpp::toAnyPtr(&pp->getDstAddr()); break;
        case FIELD_typeOfService: return (omnetpp::intval_t)(pp->getTypeOfService());
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'IpFlowInd' as cValue -- field index out of range?", field);
    }
}

void IpFlowIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        case FIELD_typeOfService: pp->setTypeOfService(omnetpp::checked_int_cast<uint16_t>(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'IpFlowInd'", field);
    }
}

const char *IpFlowIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr IpFlowIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        case FIELD_srcAddr: return omnetpp::toAnyPtr(&pp->getSrcAddr()); break;
        case FIELD_dstAddr: return omnetpp::toAnyPtr(&pp->getDstAddr()); break;
        default: return omnetpp::any_ptr(nullptr);
    }
}

void IpFlowIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    IpFlowInd *pp = omnetpp::fromAnyPtr<IpFlowInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'IpFlowInd'", field);
    }
}

Register_Class(NodeIdentificationInd)

NodeIdentificationInd::NodeIdentificationInd() : ::inet::TagBase()
{
}

NodeIdentificationInd::NodeIdentificationInd(const NodeIdentificationInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

NodeIdentificationInd::~NodeIdentificationInd()
{
}

NodeIdentificationInd& NodeIdentificationInd::operator=(const NodeIdentificationInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void NodeIdentificationInd::copy(const NodeIdentificationInd& other)
{
    this->sourceId = other.sourceId;
    this->destId = other.destId;
}

void NodeIdentificationInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->sourceId);
    doParsimPacking(b,this->destId);
}

void NodeIdentificationInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->sourceId);
    doParsimUnpacking(b,this->destId);
}

MacNodeId NodeIdentificationInd::getSourceId() const
{
    return this->sourceId;
}

void NodeIdentificationInd::setSourceId(MacNodeId sourceId)
{
    this->sourceId = sourceId;
}

MacNodeId NodeIdentificationInd::getDestId() const
{
    return this->destId;
}

void NodeIdentificationInd::setDestId(MacNodeId destId)
{
    this->destId = destId;
}

class NodeIdentificationIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_sourceId,
        FIELD_destId,
    };
  public:
    NodeIdentificationIndDescriptor();
    virtual ~NodeIdentificationIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(NodeIdentificationIndDescriptor)

NodeIdentificationIndDescriptor::NodeIdentificationIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::NodeIdentificationInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

NodeIdentificationIndDescriptor::~NodeIdentificationIndDescriptor()
{
    delete[] propertyNames;
}

bool NodeIdentificationIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<NodeIdentificationInd *>(obj)!=nullptr;
}

const char **NodeIdentificationIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *NodeIdentificationIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string NodeIdentificationIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void NodeIdentificationIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int NodeIdentificationIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 2+base->getFieldCount() : 2;
}

unsigned int NodeIdentificationIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_sourceId
        FD_ISEDITABLE,    // FIELD_destId
    };
    return (field >= 0 && field < 2) ? fieldTypeFlags[field] : 0;
}

const char *NodeIdentificationIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "sourceId",
        "destId",
    };
    return (field >= 0 && field < 2) ? fieldNames[field] : nullptr;
}

int NodeIdentificationIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "sourceId") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "destId") == 0) return baseIndex + 1;
    return base ? base->findField(fieldName) : -1;
}

const char *NodeIdentificationIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "simu5g::MacNodeId",    // FIELD_sourceId
        "simu5g::MacNodeId",    // FIELD_destId
    };
    return (field >= 0 && field < 2) ? fieldTypeStrings[field] : nullptr;
}

const char **NodeIdentificationIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *NodeIdentificationIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int NodeIdentificationIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void NodeIdentificationIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'NodeIdentificationInd'", field);
    }
}

const char *NodeIdentificationIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string NodeIdentificationIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        case FIELD_sourceId: return int642string(num(pp->getSourceId()));
        case FIELD_destId: return int642string(num(pp->getDestId()));
        default: return "";
    }
}

void NodeIdentificationIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        case FIELD_sourceId: pp->setSourceId(MacNodeId(string2int64(value))); break;
        case FIELD_destId: pp->setDestId(MacNodeId(string2int64(value))); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'NodeIdentificationInd'", field);
    }
}

omnetpp::cValue NodeIdentificationIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        case FIELD_sourceId: return num(pp->getSourceId());
        case FIELD_destId: return num(pp->getDestId());
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'NodeIdentificationInd' as cValue -- field index out of range?", field);
    }
}

void NodeIdentificationIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        case FIELD_sourceId: pp->setSourceId(MacNodeId(value.intValue())); break;
        case FIELD_destId: pp->setDestId(MacNodeId(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'NodeIdentificationInd'", field);
    }
}

const char *NodeIdentificationIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr NodeIdentificationIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void NodeIdentificationIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    NodeIdentificationInd *pp = omnetpp::fromAnyPtr<NodeIdentificationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'NodeIdentificationInd'", field);
    }
}

Register_Class(TrafficDirectionInd)

TrafficDirectionInd::TrafficDirectionInd() : ::inet::TagBase()
{
}

TrafficDirectionInd::TrafficDirectionInd(const TrafficDirectionInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

TrafficDirectionInd::~TrafficDirectionInd()
{
}

TrafficDirectionInd& TrafficDirectionInd::operator=(const TrafficDirectionInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void TrafficDirectionInd::copy(const TrafficDirectionInd& other)
{
    this->direction = other.direction;
    this->d2dTxPeerId = other.d2dTxPeerId;
    this->d2dRxPeerId = other.d2dRxPeerId;
}

void TrafficDirectionInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->direction);
    doParsimPacking(b,this->d2dTxPeerId);
    doParsimPacking(b,this->d2dRxPeerId);
}

void TrafficDirectionInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->direction);
    doParsimUnpacking(b,this->d2dTxPeerId);
    doParsimUnpacking(b,this->d2dRxPeerId);
}

unsigned short TrafficDirectionInd::getDirection() const
{
    return this->direction;
}

void TrafficDirectionInd::setDirection(unsigned short direction)
{
    this->direction = direction;
}

MacNodeId TrafficDirectionInd::getD2dTxPeerId() const
{
    return this->d2dTxPeerId;
}

void TrafficDirectionInd::setD2dTxPeerId(MacNodeId d2dTxPeerId)
{
    this->d2dTxPeerId = d2dTxPeerId;
}

MacNodeId TrafficDirectionInd::getD2dRxPeerId() const
{
    return this->d2dRxPeerId;
}

void TrafficDirectionInd::setD2dRxPeerId(MacNodeId d2dRxPeerId)
{
    this->d2dRxPeerId = d2dRxPeerId;
}

class TrafficDirectionIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_direction,
        FIELD_d2dTxPeerId,
        FIELD_d2dRxPeerId,
    };
  public:
    TrafficDirectionIndDescriptor();
    virtual ~TrafficDirectionIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(TrafficDirectionIndDescriptor)

TrafficDirectionIndDescriptor::TrafficDirectionIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::TrafficDirectionInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

TrafficDirectionIndDescriptor::~TrafficDirectionIndDescriptor()
{
    delete[] propertyNames;
}

bool TrafficDirectionIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<TrafficDirectionInd *>(obj)!=nullptr;
}

const char **TrafficDirectionIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *TrafficDirectionIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string TrafficDirectionIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void TrafficDirectionIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int TrafficDirectionIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 3+base->getFieldCount() : 3;
}

unsigned int TrafficDirectionIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_direction
        FD_ISEDITABLE,    // FIELD_d2dTxPeerId
        FD_ISEDITABLE,    // FIELD_d2dRxPeerId
    };
    return (field >= 0 && field < 3) ? fieldTypeFlags[field] : 0;
}

const char *TrafficDirectionIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "direction",
        "d2dTxPeerId",
        "d2dRxPeerId",
    };
    return (field >= 0 && field < 3) ? fieldNames[field] : nullptr;
}

int TrafficDirectionIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "direction") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "d2dTxPeerId") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "d2dRxPeerId") == 0) return baseIndex + 2;
    return base ? base->findField(fieldName) : -1;
}

const char *TrafficDirectionIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "unsigned short",    // FIELD_direction
        "simu5g::MacNodeId",    // FIELD_d2dTxPeerId
        "simu5g::MacNodeId",    // FIELD_d2dRxPeerId
    };
    return (field >= 0 && field < 3) ? fieldTypeStrings[field] : nullptr;
}

const char **TrafficDirectionIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_direction: {
            static const char *names[] = { "enum", "enum",  nullptr };
            return names;
        }
        default: return nullptr;
    }
}

const char *TrafficDirectionIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_direction:
            if (!strcmp(propertyName, "enum")) return "Direction";
            if (!strcmp(propertyName, "enum")) return "simu5g::Direction";
            return nullptr;
        default: return nullptr;
    }
}

int TrafficDirectionIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void TrafficDirectionIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'TrafficDirectionInd'", field);
    }
}

const char *TrafficDirectionIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string TrafficDirectionIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        case FIELD_direction: return enum2string(static_cast<int>(pp->getDirection()), "simu5g::Direction");
        case FIELD_d2dTxPeerId: return int642string(num(pp->getD2dTxPeerId()));
        case FIELD_d2dRxPeerId: return int642string(num(pp->getD2dRxPeerId()));
        default: return "";
    }
}

void TrafficDirectionIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        case FIELD_direction: pp->setDirection((simu5g::Direction)string2enum(value, "simu5g::Direction")); break;
        case FIELD_d2dTxPeerId: pp->setD2dTxPeerId(MacNodeId(string2int64(value))); break;
        case FIELD_d2dRxPeerId: pp->setD2dRxPeerId(MacNodeId(string2int64(value))); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TrafficDirectionInd'", field);
    }
}

omnetpp::cValue TrafficDirectionIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        case FIELD_direction: return (omnetpp::intval_t)(pp->getDirection());
        case FIELD_d2dTxPeerId: return num(pp->getD2dTxPeerId());
        case FIELD_d2dRxPeerId: return num(pp->getD2dRxPeerId());
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'TrafficDirectionInd' as cValue -- field index out of range?", field);
    }
}

void TrafficDirectionIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        case FIELD_direction: pp->setDirection((simu5g::Direction)value.intValue()); break;
        case FIELD_d2dTxPeerId: pp->setD2dTxPeerId(MacNodeId(value.intValue())); break;
        case FIELD_d2dRxPeerId: pp->setD2dRxPeerId(MacNodeId(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TrafficDirectionInd'", field);
    }
}

const char *TrafficDirectionIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr TrafficDirectionIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void TrafficDirectionIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    TrafficDirectionInd *pp = omnetpp::fromAnyPtr<TrafficDirectionInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TrafficDirectionInd'", field);
    }
}

Register_Class(TrafficClassInd)

TrafficClassInd::TrafficClassInd() : ::inet::TagBase()
{
}

TrafficClassInd::TrafficClassInd(const TrafficClassInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

TrafficClassInd::~TrafficClassInd()
{
}

TrafficClassInd& TrafficClassInd::operator=(const TrafficClassInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void TrafficClassInd::copy(const TrafficClassInd& other)
{
    this->traffic = other.traffic;
}

void TrafficClassInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->traffic);
}

void TrafficClassInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->traffic);
}

unsigned short TrafficClassInd::getTraffic() const
{
    return this->traffic;
}

void TrafficClassInd::setTraffic(unsigned short traffic)
{
    this->traffic = traffic;
}

class TrafficClassIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_traffic,
    };
  public:
    TrafficClassIndDescriptor();
    virtual ~TrafficClassIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(TrafficClassIndDescriptor)

TrafficClassIndDescriptor::TrafficClassIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::TrafficClassInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

TrafficClassIndDescriptor::~TrafficClassIndDescriptor()
{
    delete[] propertyNames;
}

bool TrafficClassIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<TrafficClassInd *>(obj)!=nullptr;
}

const char **TrafficClassIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *TrafficClassIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string TrafficClassIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void TrafficClassIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int TrafficClassIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 1+base->getFieldCount() : 1;
}

unsigned int TrafficClassIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_traffic
    };
    return (field >= 0 && field < 1) ? fieldTypeFlags[field] : 0;
}

const char *TrafficClassIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "traffic",
    };
    return (field >= 0 && field < 1) ? fieldNames[field] : nullptr;
}

int TrafficClassIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "traffic") == 0) return baseIndex + 0;
    return base ? base->findField(fieldName) : -1;
}

const char *TrafficClassIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "unsigned short",    // FIELD_traffic
    };
    return (field >= 0 && field < 1) ? fieldTypeStrings[field] : nullptr;
}

const char **TrafficClassIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_traffic: {
            static const char *names[] = { "enum", "enum",  nullptr };
            return names;
        }
        default: return nullptr;
    }
}

const char *TrafficClassIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_traffic:
            if (!strcmp(propertyName, "enum")) return "LteTrafficClass";
            if (!strcmp(propertyName, "enum")) return "simu5g::LteTrafficClass";
            return nullptr;
        default: return nullptr;
    }
}

int TrafficClassIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void TrafficClassIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'TrafficClassInd'", field);
    }
}

const char *TrafficClassIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string TrafficClassIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        case FIELD_traffic: return enum2string(static_cast<int>(pp->getTraffic()), "simu5g::LteTrafficClass");
        default: return "";
    }
}

void TrafficClassIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        case FIELD_traffic: pp->setTraffic((simu5g::LteTrafficClass)string2enum(value, "simu5g::LteTrafficClass")); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TrafficClassInd'", field);
    }
}

omnetpp::cValue TrafficClassIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        case FIELD_traffic: return (omnetpp::intval_t)(pp->getTraffic());
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'TrafficClassInd' as cValue -- field index out of range?", field);
    }
}

void TrafficClassIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        case FIELD_traffic: pp->setTraffic((simu5g::LteTrafficClass)value.intValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TrafficClassInd'", field);
    }
}

const char *TrafficClassIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr TrafficClassIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void TrafficClassIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    TrafficClassInd *pp = omnetpp::fromAnyPtr<TrafficClassInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TrafficClassInd'", field);
    }
}

Register_Class(LogicalConnectionInd)

LogicalConnectionInd::LogicalConnectionInd() : ::inet::TagBase()
{
}

LogicalConnectionInd::LogicalConnectionInd(const LogicalConnectionInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

LogicalConnectionInd::~LogicalConnectionInd()
{
}

LogicalConnectionInd& LogicalConnectionInd::operator=(const LogicalConnectionInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void LogicalConnectionInd::copy(const LogicalConnectionInd& other)
{
    this->lcid = other.lcid;
    this->multicastGroupId = other.multicastGroupId;
}

void LogicalConnectionInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->lcid);
    doParsimPacking(b,this->multicastGroupId);
}

void LogicalConnectionInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->lcid);
    doParsimUnpacking(b,this->multicastGroupId);
}

uint16_t LogicalConnectionInd::getLcid() const
{
    return this->lcid;
}

void LogicalConnectionInd::setLcid(uint16_t lcid)
{
    this->lcid = lcid;
}

int32_t LogicalConnectionInd::getMulticastGroupId() const
{
    return this->multicastGroupId;
}

void LogicalConnectionInd::setMulticastGroupId(int32_t multicastGroupId)
{
    this->multicastGroupId = multicastGroupId;
}

class LogicalConnectionIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_lcid,
        FIELD_multicastGroupId,
    };
  public:
    LogicalConnectionIndDescriptor();
    virtual ~LogicalConnectionIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(LogicalConnectionIndDescriptor)

LogicalConnectionIndDescriptor::LogicalConnectionIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::LogicalConnectionInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

LogicalConnectionIndDescriptor::~LogicalConnectionIndDescriptor()
{
    delete[] propertyNames;
}

bool LogicalConnectionIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<LogicalConnectionInd *>(obj)!=nullptr;
}

const char **LogicalConnectionIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *LogicalConnectionIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string LogicalConnectionIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void LogicalConnectionIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int LogicalConnectionIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 2+base->getFieldCount() : 2;
}

unsigned int LogicalConnectionIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_lcid
        FD_ISEDITABLE,    // FIELD_multicastGroupId
    };
    return (field >= 0 && field < 2) ? fieldTypeFlags[field] : 0;
}

const char *LogicalConnectionIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "lcid",
        "multicastGroupId",
    };
    return (field >= 0 && field < 2) ? fieldNames[field] : nullptr;
}

int LogicalConnectionIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "lcid") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "multicastGroupId") == 0) return baseIndex + 1;
    return base ? base->findField(fieldName) : -1;
}

const char *LogicalConnectionIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "uint16",    // FIELD_lcid
        "int32",    // FIELD_multicastGroupId
    };
    return (field >= 0 && field < 2) ? fieldTypeStrings[field] : nullptr;
}

const char **LogicalConnectionIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *LogicalConnectionIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int LogicalConnectionIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void LogicalConnectionIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'LogicalConnectionInd'", field);
    }
}

const char *LogicalConnectionIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string LogicalConnectionIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        case FIELD_lcid: return ulong2string(pp->getLcid());
        case FIELD_multicastGroupId: return long2string(pp->getMulticastGroupId());
        default: return "";
    }
}

void LogicalConnectionIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        case FIELD_lcid: pp->setLcid(string2ulong(value)); break;
        case FIELD_multicastGroupId: pp->setMulticastGroupId(string2long(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'LogicalConnectionInd'", field);
    }
}

omnetpp::cValue LogicalConnectionIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        case FIELD_lcid: return (omnetpp::intval_t)(pp->getLcid());
        case FIELD_multicastGroupId: return pp->getMulticastGroupId();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'LogicalConnectionInd' as cValue -- field index out of range?", field);
    }
}

void LogicalConnectionIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        case FIELD_lcid: pp->setLcid(omnetpp::checked_int_cast<uint16_t>(value.intValue())); break;
        case FIELD_multicastGroupId: pp->setMulticastGroupId(omnetpp::checked_int_cast<int32_t>(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'LogicalConnectionInd'", field);
    }
}

const char *LogicalConnectionIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr LogicalConnectionIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void LogicalConnectionIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    LogicalConnectionInd *pp = omnetpp::fromAnyPtr<LogicalConnectionInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'LogicalConnectionInd'", field);
    }
}

Register_Class(RlcConfigurationTagBase)

RlcConfigurationTagBase::RlcConfigurationTagBase() : ::inet::TagBase()
{
}

RlcConfigurationTagBase::RlcConfigurationTagBase(const RlcConfigurationTagBase& other) : ::inet::TagBase(other)
{
    copy(other);
}

RlcConfigurationTagBase::~RlcConfigurationTagBase()
{
}

RlcConfigurationTagBase& RlcConfigurationTagBase::operator=(const RlcConfigurationTagBase& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void RlcConfigurationTagBase::copy(const RlcConfigurationTagBase& other)
{
    this->rlcType = other.rlcType;
}

void RlcConfigurationTagBase::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->rlcType);
}

void RlcConfigurationTagBase::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->rlcType);
}

unsigned short RlcConfigurationTagBase::getRlcType() const
{
    return this->rlcType;
}

void RlcConfigurationTagBase::setRlcType(unsigned short rlcType)
{
    this->rlcType = rlcType;
}

class RlcConfigurationTagBaseDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_rlcType,
    };
  public:
    RlcConfigurationTagBaseDescriptor();
    virtual ~RlcConfigurationTagBaseDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(RlcConfigurationTagBaseDescriptor)

RlcConfigurationTagBaseDescriptor::RlcConfigurationTagBaseDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::RlcConfigurationTagBase)), "inet::TagBase")
{
    propertyNames = nullptr;
}

RlcConfigurationTagBaseDescriptor::~RlcConfigurationTagBaseDescriptor()
{
    delete[] propertyNames;
}

bool RlcConfigurationTagBaseDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<RlcConfigurationTagBase *>(obj)!=nullptr;
}

const char **RlcConfigurationTagBaseDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *RlcConfigurationTagBaseDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string RlcConfigurationTagBaseDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void RlcConfigurationTagBaseDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int RlcConfigurationTagBaseDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 1+base->getFieldCount() : 1;
}

unsigned int RlcConfigurationTagBaseDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_rlcType
    };
    return (field >= 0 && field < 1) ? fieldTypeFlags[field] : 0;
}

const char *RlcConfigurationTagBaseDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "rlcType",
    };
    return (field >= 0 && field < 1) ? fieldNames[field] : nullptr;
}

int RlcConfigurationTagBaseDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "rlcType") == 0) return baseIndex + 0;
    return base ? base->findField(fieldName) : -1;
}

const char *RlcConfigurationTagBaseDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "unsigned short",    // FIELD_rlcType
    };
    return (field >= 0 && field < 1) ? fieldTypeStrings[field] : nullptr;
}

const char **RlcConfigurationTagBaseDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_rlcType: {
            static const char *names[] = { "enum", "enum",  nullptr };
            return names;
        }
        default: return nullptr;
    }
}

const char *RlcConfigurationTagBaseDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_rlcType:
            if (!strcmp(propertyName, "enum")) return "LteRlcType";
            if (!strcmp(propertyName, "enum")) return "simu5g::LteRlcType";
            return nullptr;
        default: return nullptr;
    }
}

int RlcConfigurationTagBaseDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void RlcConfigurationTagBaseDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'RlcConfigurationTagBase'", field);
    }
}

const char *RlcConfigurationTagBaseDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string RlcConfigurationTagBaseDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        case FIELD_rlcType: return enum2string(static_cast<int>(pp->getRlcType()), "simu5g::LteRlcType");
        default: return "";
    }
}

void RlcConfigurationTagBaseDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        case FIELD_rlcType: pp->setRlcType((simu5g::LteRlcType)string2enum(value, "simu5g::LteRlcType")); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationTagBase'", field);
    }
}

omnetpp::cValue RlcConfigurationTagBaseDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        case FIELD_rlcType: return (omnetpp::intval_t)(pp->getRlcType());
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'RlcConfigurationTagBase' as cValue -- field index out of range?", field);
    }
}

void RlcConfigurationTagBaseDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        case FIELD_rlcType: pp->setRlcType((simu5g::LteRlcType)value.intValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationTagBase'", field);
    }
}

const char *RlcConfigurationTagBaseDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr RlcConfigurationTagBaseDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void RlcConfigurationTagBaseDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationTagBase *pp = omnetpp::fromAnyPtr<RlcConfigurationTagBase>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationTagBase'", field);
    }
}

Register_Class(RlcConfigurationReq)

RlcConfigurationReq::RlcConfigurationReq() : ::simu5g::RlcConfigurationTagBase()
{
}

RlcConfigurationReq::RlcConfigurationReq(const RlcConfigurationReq& other) : ::simu5g::RlcConfigurationTagBase(other)
{
    copy(other);
}

RlcConfigurationReq::~RlcConfigurationReq()
{
}

RlcConfigurationReq& RlcConfigurationReq::operator=(const RlcConfigurationReq& other)
{
    if (this == &other) return *this;
    ::simu5g::RlcConfigurationTagBase::operator=(other);
    copy(other);
    return *this;
}

void RlcConfigurationReq::copy(const RlcConfigurationReq& other)
{
}

void RlcConfigurationReq::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::simu5g::RlcConfigurationTagBase::parsimPack(b);
}

void RlcConfigurationReq::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::simu5g::RlcConfigurationTagBase::parsimUnpack(b);
}

class RlcConfigurationReqDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
    };
  public:
    RlcConfigurationReqDescriptor();
    virtual ~RlcConfigurationReqDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(RlcConfigurationReqDescriptor)

RlcConfigurationReqDescriptor::RlcConfigurationReqDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::RlcConfigurationReq)), "simu5g::RlcConfigurationTagBase")
{
    propertyNames = nullptr;
}

RlcConfigurationReqDescriptor::~RlcConfigurationReqDescriptor()
{
    delete[] propertyNames;
}

bool RlcConfigurationReqDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<RlcConfigurationReq *>(obj)!=nullptr;
}

const char **RlcConfigurationReqDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *RlcConfigurationReqDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string RlcConfigurationReqDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void RlcConfigurationReqDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int RlcConfigurationReqDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 0+base->getFieldCount() : 0;
}

unsigned int RlcConfigurationReqDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    return 0;
}

const char *RlcConfigurationReqDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

int RlcConfigurationReqDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->findField(fieldName) : -1;
}

const char *RlcConfigurationReqDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

const char **RlcConfigurationReqDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *RlcConfigurationReqDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int RlcConfigurationReqDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void RlcConfigurationReqDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'RlcConfigurationReq'", field);
    }
}

const char *RlcConfigurationReqDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string RlcConfigurationReqDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: return "";
    }
}

void RlcConfigurationReqDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationReq'", field);
    }
}

omnetpp::cValue RlcConfigurationReqDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'RlcConfigurationReq' as cValue -- field index out of range?", field);
    }
}

void RlcConfigurationReqDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationReq'", field);
    }
}

const char *RlcConfigurationReqDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

omnetpp::any_ptr RlcConfigurationReqDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void RlcConfigurationReqDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationReq *pp = omnetpp::fromAnyPtr<RlcConfigurationReq>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationReq'", field);
    }
}

Register_Class(RlcConfigurationInd)

RlcConfigurationInd::RlcConfigurationInd() : ::simu5g::RlcConfigurationTagBase()
{
}

RlcConfigurationInd::RlcConfigurationInd(const RlcConfigurationInd& other) : ::simu5g::RlcConfigurationTagBase(other)
{
    copy(other);
}

RlcConfigurationInd::~RlcConfigurationInd()
{
}

RlcConfigurationInd& RlcConfigurationInd::operator=(const RlcConfigurationInd& other)
{
    if (this == &other) return *this;
    ::simu5g::RlcConfigurationTagBase::operator=(other);
    copy(other);
    return *this;
}

void RlcConfigurationInd::copy(const RlcConfigurationInd& other)
{
}

void RlcConfigurationInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::simu5g::RlcConfigurationTagBase::parsimPack(b);
}

void RlcConfigurationInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::simu5g::RlcConfigurationTagBase::parsimUnpack(b);
}

class RlcConfigurationIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
    };
  public:
    RlcConfigurationIndDescriptor();
    virtual ~RlcConfigurationIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(RlcConfigurationIndDescriptor)

RlcConfigurationIndDescriptor::RlcConfigurationIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::RlcConfigurationInd)), "simu5g::RlcConfigurationTagBase")
{
    propertyNames = nullptr;
}

RlcConfigurationIndDescriptor::~RlcConfigurationIndDescriptor()
{
    delete[] propertyNames;
}

bool RlcConfigurationIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<RlcConfigurationInd *>(obj)!=nullptr;
}

const char **RlcConfigurationIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *RlcConfigurationIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string RlcConfigurationIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void RlcConfigurationIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int RlcConfigurationIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 0+base->getFieldCount() : 0;
}

unsigned int RlcConfigurationIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    return 0;
}

const char *RlcConfigurationIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

int RlcConfigurationIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->findField(fieldName) : -1;
}

const char *RlcConfigurationIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

const char **RlcConfigurationIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *RlcConfigurationIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int RlcConfigurationIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void RlcConfigurationIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'RlcConfigurationInd'", field);
    }
}

const char *RlcConfigurationIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string RlcConfigurationIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: return "";
    }
}

void RlcConfigurationIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationInd'", field);
    }
}

omnetpp::cValue RlcConfigurationIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'RlcConfigurationInd' as cValue -- field index out of range?", field);
    }
}

void RlcConfigurationIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationInd'", field);
    }
}

const char *RlcConfigurationIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

omnetpp::any_ptr RlcConfigurationIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void RlcConfigurationIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    RlcConfigurationInd *pp = omnetpp::fromAnyPtr<RlcConfigurationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'RlcConfigurationInd'", field);
    }
}

Register_Class(TechnologyReq)

TechnologyReq::TechnologyReq() : ::inet::TagBase()
{
}

TechnologyReq::TechnologyReq(const TechnologyReq& other) : ::inet::TagBase(other)
{
    copy(other);
}

TechnologyReq::~TechnologyReq()
{
}

TechnologyReq& TechnologyReq::operator=(const TechnologyReq& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void TechnologyReq::copy(const TechnologyReq& other)
{
    this->useNR = other.useNR;
}

void TechnologyReq::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->useNR);
}

void TechnologyReq::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->useNR);
}

bool TechnologyReq::getUseNR() const
{
    return this->useNR;
}

void TechnologyReq::setUseNR(bool useNR)
{
    this->useNR = useNR;
}

class TechnologyReqDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_useNR,
    };
  public:
    TechnologyReqDescriptor();
    virtual ~TechnologyReqDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(TechnologyReqDescriptor)

TechnologyReqDescriptor::TechnologyReqDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::TechnologyReq)), "inet::TagBase")
{
    propertyNames = nullptr;
}

TechnologyReqDescriptor::~TechnologyReqDescriptor()
{
    delete[] propertyNames;
}

bool TechnologyReqDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<TechnologyReq *>(obj)!=nullptr;
}

const char **TechnologyReqDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *TechnologyReqDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string TechnologyReqDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void TechnologyReqDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int TechnologyReqDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 1+base->getFieldCount() : 1;
}

unsigned int TechnologyReqDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_useNR
    };
    return (field >= 0 && field < 1) ? fieldTypeFlags[field] : 0;
}

const char *TechnologyReqDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "useNR",
    };
    return (field >= 0 && field < 1) ? fieldNames[field] : nullptr;
}

int TechnologyReqDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "useNR") == 0) return baseIndex + 0;
    return base ? base->findField(fieldName) : -1;
}

const char *TechnologyReqDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "bool",    // FIELD_useNR
    };
    return (field >= 0 && field < 1) ? fieldTypeStrings[field] : nullptr;
}

const char **TechnologyReqDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *TechnologyReqDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int TechnologyReqDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void TechnologyReqDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'TechnologyReq'", field);
    }
}

const char *TechnologyReqDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string TechnologyReqDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        case FIELD_useNR: return bool2string(pp->getUseNR());
        default: return "";
    }
}

void TechnologyReqDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        case FIELD_useNR: pp->setUseNR(string2bool(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TechnologyReq'", field);
    }
}

omnetpp::cValue TechnologyReqDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        case FIELD_useNR: return pp->getUseNR();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'TechnologyReq' as cValue -- field index out of range?", field);
    }
}

void TechnologyReqDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        case FIELD_useNR: pp->setUseNR(value.boolValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TechnologyReq'", field);
    }
}

const char *TechnologyReqDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr TechnologyReqDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void TechnologyReqDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    TechnologyReq *pp = omnetpp::fromAnyPtr<TechnologyReq>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'TechnologyReq'", field);
    }
}

Register_Class(CarrierConfigurationInd)

CarrierConfigurationInd::CarrierConfigurationInd() : ::inet::TagBase()
{
}

CarrierConfigurationInd::CarrierConfigurationInd(const CarrierConfigurationInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

CarrierConfigurationInd::~CarrierConfigurationInd()
{
}

CarrierConfigurationInd& CarrierConfigurationInd::operator=(const CarrierConfigurationInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void CarrierConfigurationInd::copy(const CarrierConfigurationInd& other)
{
    this->isNr_ = other.isNr_;
    this->carrierFrequency = other.carrierFrequency;
}

void CarrierConfigurationInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->isNr_);
    doParsimPacking(b,this->carrierFrequency);
}

void CarrierConfigurationInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->isNr_);
    doParsimUnpacking(b,this->carrierFrequency);
}

bool CarrierConfigurationInd::isNr() const
{
    return this->isNr_;
}

void CarrierConfigurationInd::setIsNr(bool isNr)
{
    this->isNr_ = isNr;
}

double CarrierConfigurationInd::getCarrierFrequency() const
{
    return this->carrierFrequency;
}

void CarrierConfigurationInd::setCarrierFrequency(double carrierFrequency)
{
    this->carrierFrequency = carrierFrequency;
}

class CarrierConfigurationIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_isNr,
        FIELD_carrierFrequency,
    };
  public:
    CarrierConfigurationIndDescriptor();
    virtual ~CarrierConfigurationIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(CarrierConfigurationIndDescriptor)

CarrierConfigurationIndDescriptor::CarrierConfigurationIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::CarrierConfigurationInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

CarrierConfigurationIndDescriptor::~CarrierConfigurationIndDescriptor()
{
    delete[] propertyNames;
}

bool CarrierConfigurationIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<CarrierConfigurationInd *>(obj)!=nullptr;
}

const char **CarrierConfigurationIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *CarrierConfigurationIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string CarrierConfigurationIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void CarrierConfigurationIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int CarrierConfigurationIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 2+base->getFieldCount() : 2;
}

unsigned int CarrierConfigurationIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_isNr
        FD_ISEDITABLE,    // FIELD_carrierFrequency
    };
    return (field >= 0 && field < 2) ? fieldTypeFlags[field] : 0;
}

const char *CarrierConfigurationIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "isNr",
        "carrierFrequency",
    };
    return (field >= 0 && field < 2) ? fieldNames[field] : nullptr;
}

int CarrierConfigurationIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "isNr") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "carrierFrequency") == 0) return baseIndex + 1;
    return base ? base->findField(fieldName) : -1;
}

const char *CarrierConfigurationIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "bool",    // FIELD_isNr
        "double",    // FIELD_carrierFrequency
    };
    return (field >= 0 && field < 2) ? fieldTypeStrings[field] : nullptr;
}

const char **CarrierConfigurationIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *CarrierConfigurationIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int CarrierConfigurationIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void CarrierConfigurationIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'CarrierConfigurationInd'", field);
    }
}

const char *CarrierConfigurationIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string CarrierConfigurationIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        case FIELD_isNr: return bool2string(pp->isNr());
        case FIELD_carrierFrequency: return double2string(pp->getCarrierFrequency());
        default: return "";
    }
}

void CarrierConfigurationIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        case FIELD_isNr: pp->setIsNr(string2bool(value)); break;
        case FIELD_carrierFrequency: pp->setCarrierFrequency(string2double(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'CarrierConfigurationInd'", field);
    }
}

omnetpp::cValue CarrierConfigurationIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        case FIELD_isNr: return pp->isNr();
        case FIELD_carrierFrequency: return pp->getCarrierFrequency();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'CarrierConfigurationInd' as cValue -- field index out of range?", field);
    }
}

void CarrierConfigurationIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        case FIELD_isNr: pp->setIsNr(value.boolValue()); break;
        case FIELD_carrierFrequency: pp->setCarrierFrequency(value.doubleValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'CarrierConfigurationInd'", field);
    }
}

const char *CarrierConfigurationIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr CarrierConfigurationIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void CarrierConfigurationIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    CarrierConfigurationInd *pp = omnetpp::fromAnyPtr<CarrierConfigurationInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'CarrierConfigurationInd'", field);
    }
}

Register_Class(HarqInfoInd)

HarqInfoInd::HarqInfoInd() : ::inet::TagBase()
{
}

HarqInfoInd::HarqInfoInd(const HarqInfoInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

HarqInfoInd::~HarqInfoInd()
{
}

HarqInfoInd& HarqInfoInd::operator=(const HarqInfoInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void HarqInfoInd::copy(const HarqInfoInd& other)
{
    this->acid = other.acid;
    this->cw = other.cw;
    this->txNumber = other.txNumber;
    this->ndi = other.ndi;
}

void HarqInfoInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->acid);
    doParsimPacking(b,this->cw);
    doParsimPacking(b,this->txNumber);
    doParsimPacking(b,this->ndi);
}

void HarqInfoInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->acid);
    doParsimUnpacking(b,this->cw);
    doParsimUnpacking(b,this->txNumber);
    doParsimUnpacking(b,this->ndi);
}

unsigned char HarqInfoInd::getAcid() const
{
    return this->acid;
}

void HarqInfoInd::setAcid(unsigned char acid)
{
    this->acid = acid;
}

unsigned char HarqInfoInd::getCw() const
{
    return this->cw;
}

void HarqInfoInd::setCw(unsigned char cw)
{
    this->cw = cw;
}

unsigned char HarqInfoInd::getTxNumber() const
{
    return this->txNumber;
}

void HarqInfoInd::setTxNumber(unsigned char txNumber)
{
    this->txNumber = txNumber;
}

bool HarqInfoInd::getNdi() const
{
    return this->ndi;
}

void HarqInfoInd::setNdi(bool ndi)
{
    this->ndi = ndi;
}

class HarqInfoIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_acid,
        FIELD_cw,
        FIELD_txNumber,
        FIELD_ndi,
    };
  public:
    HarqInfoIndDescriptor();
    virtual ~HarqInfoIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(HarqInfoIndDescriptor)

HarqInfoIndDescriptor::HarqInfoIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::HarqInfoInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

HarqInfoIndDescriptor::~HarqInfoIndDescriptor()
{
    delete[] propertyNames;
}

bool HarqInfoIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<HarqInfoInd *>(obj)!=nullptr;
}

const char **HarqInfoIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *HarqInfoIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string HarqInfoIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void HarqInfoIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int HarqInfoIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 4+base->getFieldCount() : 4;
}

unsigned int HarqInfoIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_acid
        FD_ISEDITABLE,    // FIELD_cw
        FD_ISEDITABLE,    // FIELD_txNumber
        FD_ISEDITABLE,    // FIELD_ndi
    };
    return (field >= 0 && field < 4) ? fieldTypeFlags[field] : 0;
}

const char *HarqInfoIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "acid",
        "cw",
        "txNumber",
        "ndi",
    };
    return (field >= 0 && field < 4) ? fieldNames[field] : nullptr;
}

int HarqInfoIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "acid") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "cw") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "txNumber") == 0) return baseIndex + 2;
    if (strcmp(fieldName, "ndi") == 0) return baseIndex + 3;
    return base ? base->findField(fieldName) : -1;
}

const char *HarqInfoIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "unsigned char",    // FIELD_acid
        "unsigned char",    // FIELD_cw
        "unsigned char",    // FIELD_txNumber
        "bool",    // FIELD_ndi
    };
    return (field >= 0 && field < 4) ? fieldTypeStrings[field] : nullptr;
}

const char **HarqInfoIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *HarqInfoIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int HarqInfoIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void HarqInfoIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'HarqInfoInd'", field);
    }
}

const char *HarqInfoIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string HarqInfoIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        case FIELD_acid: return ulong2string(pp->getAcid());
        case FIELD_cw: return ulong2string(pp->getCw());
        case FIELD_txNumber: return ulong2string(pp->getTxNumber());
        case FIELD_ndi: return bool2string(pp->getNdi());
        default: return "";
    }
}

void HarqInfoIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        case FIELD_acid: pp->setAcid(string2ulong(value)); break;
        case FIELD_cw: pp->setCw(string2ulong(value)); break;
        case FIELD_txNumber: pp->setTxNumber(string2ulong(value)); break;
        case FIELD_ndi: pp->setNdi(string2bool(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'HarqInfoInd'", field);
    }
}

omnetpp::cValue HarqInfoIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        case FIELD_acid: return (omnetpp::intval_t)(pp->getAcid());
        case FIELD_cw: return (omnetpp::intval_t)(pp->getCw());
        case FIELD_txNumber: return (omnetpp::intval_t)(pp->getTxNumber());
        case FIELD_ndi: return pp->getNdi();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'HarqInfoInd' as cValue -- field index out of range?", field);
    }
}

void HarqInfoIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        case FIELD_acid: pp->setAcid(omnetpp::checked_int_cast<unsigned char>(value.intValue())); break;
        case FIELD_cw: pp->setCw(omnetpp::checked_int_cast<unsigned char>(value.intValue())); break;
        case FIELD_txNumber: pp->setTxNumber(omnetpp::checked_int_cast<unsigned char>(value.intValue())); break;
        case FIELD_ndi: pp->setNdi(value.boolValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'HarqInfoInd'", field);
    }
}

const char *HarqInfoIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr HarqInfoIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void HarqInfoIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    HarqInfoInd *pp = omnetpp::fromAnyPtr<HarqInfoInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'HarqInfoInd'", field);
    }
}

Register_Class(PhyTransmissionInd)

PhyTransmissionInd::PhyTransmissionInd() : ::inet::TagBase()
{
}

PhyTransmissionInd::PhyTransmissionInd(const PhyTransmissionInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

PhyTransmissionInd::~PhyTransmissionInd()
{
}

PhyTransmissionInd& PhyTransmissionInd::operator=(const PhyTransmissionInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void PhyTransmissionInd::copy(const PhyTransmissionInd& other)
{
    this->txMode = other.txMode;
    this->frameType = other.frameType;
    this->txPower = other.txPower;
    this->d2dTxPower = other.d2dTxPower;
    this->totalGrantedBlocks = other.totalGrantedBlocks;
    this->grantId = other.grantId;
    this->coord = other.coord;
    this->grantedBlocks = other.grantedBlocks;
    this->feedbackReq = other.feedbackReq;
}

void PhyTransmissionInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->txMode);
    doParsimPacking(b,this->frameType);
    doParsimPacking(b,this->txPower);
    doParsimPacking(b,this->d2dTxPower);
    doParsimPacking(b,this->totalGrantedBlocks);
    doParsimPacking(b,this->grantId);
    doParsimPacking(b,this->coord);
    doParsimPacking(b,this->grantedBlocks);
    doParsimPacking(b,this->feedbackReq);
}

void PhyTransmissionInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->txMode);
    doParsimUnpacking(b,this->frameType);
    doParsimUnpacking(b,this->txPower);
    doParsimUnpacking(b,this->d2dTxPower);
    doParsimUnpacking(b,this->totalGrantedBlocks);
    doParsimUnpacking(b,this->grantId);
    doParsimUnpacking(b,this->coord);
    doParsimUnpacking(b,this->grantedBlocks);
    doParsimUnpacking(b,this->feedbackReq);
}

unsigned short PhyTransmissionInd::getTxMode() const
{
    return this->txMode;
}

void PhyTransmissionInd::setTxMode(unsigned short txMode)
{
    this->txMode = txMode;
}

unsigned int PhyTransmissionInd::getFrameType() const
{
    return this->frameType;
}

void PhyTransmissionInd::setFrameType(unsigned int frameType)
{
    this->frameType = frameType;
}

double PhyTransmissionInd::getTxPower() const
{
    return this->txPower;
}

void PhyTransmissionInd::setTxPower(double txPower)
{
    this->txPower = txPower;
}

double PhyTransmissionInd::getD2dTxPower() const
{
    return this->d2dTxPower;
}

void PhyTransmissionInd::setD2dTxPower(double d2dTxPower)
{
    this->d2dTxPower = d2dTxPower;
}

unsigned int PhyTransmissionInd::getTotalGrantedBlocks() const
{
    return this->totalGrantedBlocks;
}

void PhyTransmissionInd::setTotalGrantedBlocks(unsigned int totalGrantedBlocks)
{
    this->totalGrantedBlocks = totalGrantedBlocks;
}

unsigned int PhyTransmissionInd::getGrantId() const
{
    return this->grantId;
}

void PhyTransmissionInd::setGrantId(unsigned int grantId)
{
    this->grantId = grantId;
}

const ::inet::Coord& PhyTransmissionInd::getCoord() const
{
    return this->coord;
}

void PhyTransmissionInd::setCoord(const ::inet::Coord& coord)
{
    this->coord = coord;
}

const RbMap& PhyTransmissionInd::getGrantedBlocks() const
{
    return this->grantedBlocks;
}

void PhyTransmissionInd::setGrantedBlocks(const RbMap& grantedBlocks)
{
    this->grantedBlocks = grantedBlocks;
}

const FeedbackRequest& PhyTransmissionInd::getFeedbackReq() const
{
    return this->feedbackReq;
}

void PhyTransmissionInd::setFeedbackReq(const FeedbackRequest& feedbackReq)
{
    this->feedbackReq = feedbackReq;
}

class PhyTransmissionIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_txMode,
        FIELD_frameType,
        FIELD_txPower,
        FIELD_d2dTxPower,
        FIELD_totalGrantedBlocks,
        FIELD_grantId,
        FIELD_coord,
        FIELD_grantedBlocks,
        FIELD_feedbackReq,
    };
  public:
    PhyTransmissionIndDescriptor();
    virtual ~PhyTransmissionIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(PhyTransmissionIndDescriptor)

PhyTransmissionIndDescriptor::PhyTransmissionIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::PhyTransmissionInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

PhyTransmissionIndDescriptor::~PhyTransmissionIndDescriptor()
{
    delete[] propertyNames;
}

bool PhyTransmissionIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<PhyTransmissionInd *>(obj)!=nullptr;
}

const char **PhyTransmissionIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *PhyTransmissionIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string PhyTransmissionIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void PhyTransmissionIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int PhyTransmissionIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 9+base->getFieldCount() : 9;
}

unsigned int PhyTransmissionIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_txMode
        FD_ISEDITABLE,    // FIELD_frameType
        FD_ISEDITABLE,    // FIELD_txPower
        FD_ISEDITABLE,    // FIELD_d2dTxPower
        FD_ISEDITABLE,    // FIELD_totalGrantedBlocks
        FD_ISEDITABLE,    // FIELD_grantId
        FD_ISCOMPOUND,    // FIELD_coord
        0,    // FIELD_grantedBlocks
        FD_ISCOMPOUND,    // FIELD_feedbackReq
    };
    return (field >= 0 && field < 9) ? fieldTypeFlags[field] : 0;
}

const char *PhyTransmissionIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "txMode",
        "frameType",
        "txPower",
        "d2dTxPower",
        "totalGrantedBlocks",
        "grantId",
        "coord",
        "grantedBlocks",
        "feedbackReq",
    };
    return (field >= 0 && field < 9) ? fieldNames[field] : nullptr;
}

int PhyTransmissionIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "txMode") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "frameType") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "txPower") == 0) return baseIndex + 2;
    if (strcmp(fieldName, "d2dTxPower") == 0) return baseIndex + 3;
    if (strcmp(fieldName, "totalGrantedBlocks") == 0) return baseIndex + 4;
    if (strcmp(fieldName, "grantId") == 0) return baseIndex + 5;
    if (strcmp(fieldName, "coord") == 0) return baseIndex + 6;
    if (strcmp(fieldName, "grantedBlocks") == 0) return baseIndex + 7;
    if (strcmp(fieldName, "feedbackReq") == 0) return baseIndex + 8;
    return base ? base->findField(fieldName) : -1;
}

const char *PhyTransmissionIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "unsigned short",    // FIELD_txMode
        "unsigned int",    // FIELD_frameType
        "double",    // FIELD_txPower
        "double",    // FIELD_d2dTxPower
        "unsigned int",    // FIELD_totalGrantedBlocks
        "unsigned int",    // FIELD_grantId
        "inet::Coord",    // FIELD_coord
        "simu5g::RbMap",    // FIELD_grantedBlocks
        "simu5g::FeedbackRequest",    // FIELD_feedbackReq
    };
    return (field >= 0 && field < 9) ? fieldTypeStrings[field] : nullptr;
}

const char **PhyTransmissionIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_txMode: {
            static const char *names[] = { "enum", "enum",  nullptr };
            return names;
        }
        case FIELD_frameType: {
            static const char *names[] = { "enum", "enum",  nullptr };
            return names;
        }
        default: return nullptr;
    }
}

const char *PhyTransmissionIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_txMode:
            if (!strcmp(propertyName, "enum")) return "TxMode";
            if (!strcmp(propertyName, "enum")) return "simu5g::TxMode";
            return nullptr;
        case FIELD_frameType:
            if (!strcmp(propertyName, "enum")) return "LtePhyFrameType";
            if (!strcmp(propertyName, "enum")) return "simu5g::LtePhyFrameType";
            return nullptr;
        default: return nullptr;
    }
}

int PhyTransmissionIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void PhyTransmissionIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'PhyTransmissionInd'", field);
    }
}

const char *PhyTransmissionIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string PhyTransmissionIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        case FIELD_txMode: return enum2string(static_cast<int>(pp->getTxMode()), "simu5g::TxMode");
        case FIELD_frameType: return enum2string(static_cast<int>(pp->getFrameType()), "simu5g::LtePhyFrameType");
        case FIELD_txPower: return double2string(pp->getTxPower());
        case FIELD_d2dTxPower: return double2string(pp->getD2dTxPower());
        case FIELD_totalGrantedBlocks: return ulong2string(pp->getTotalGrantedBlocks());
        case FIELD_grantId: return ulong2string(pp->getGrantId());
        case FIELD_coord: return pp->getCoord().str();
        case FIELD_grantedBlocks: return "";
        case FIELD_feedbackReq: return "";
        default: return "";
    }
}

void PhyTransmissionIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        case FIELD_txMode: pp->setTxMode((simu5g::TxMode)string2enum(value, "simu5g::TxMode")); break;
        case FIELD_frameType: pp->setFrameType((simu5g::LtePhyFrameType)string2enum(value, "simu5g::LtePhyFrameType")); break;
        case FIELD_txPower: pp->setTxPower(string2double(value)); break;
        case FIELD_d2dTxPower: pp->setD2dTxPower(string2double(value)); break;
        case FIELD_totalGrantedBlocks: pp->setTotalGrantedBlocks(string2ulong(value)); break;
        case FIELD_grantId: pp->setGrantId(string2ulong(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'PhyTransmissionInd'", field);
    }
}

omnetpp::cValue PhyTransmissionIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        case FIELD_txMode: return (omnetpp::intval_t)(pp->getTxMode());
        case FIELD_frameType: return (omnetpp::intval_t)(pp->getFrameType());
        case FIELD_txPower: return pp->getTxPower();
        case FIELD_d2dTxPower: return pp->getD2dTxPower();
        case FIELD_totalGrantedBlocks: return (omnetpp::intval_t)(pp->getTotalGrantedBlocks());
        case FIELD_grantId: return (omnetpp::intval_t)(pp->getGrantId());
        case FIELD_coord: return omnetpp::toAnyPtr(&pp->getCoord()); break;
        case FIELD_grantedBlocks: return omnetpp::toAnyPtr(&pp->getGrantedBlocks()); break;
        case FIELD_feedbackReq: return omnetpp::toAnyPtr(&pp->getFeedbackReq()); break;
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'PhyTransmissionInd' as cValue -- field index out of range?", field);
    }
}

void PhyTransmissionIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        case FIELD_txMode: pp->setTxMode((simu5g::TxMode)value.intValue()); break;
        case FIELD_frameType: pp->setFrameType((simu5g::LtePhyFrameType)value.intValue()); break;
        case FIELD_txPower: pp->setTxPower(value.doubleValue()); break;
        case FIELD_d2dTxPower: pp->setD2dTxPower(value.doubleValue()); break;
        case FIELD_totalGrantedBlocks: pp->setTotalGrantedBlocks(omnetpp::checked_int_cast<unsigned int>(value.intValue())); break;
        case FIELD_grantId: pp->setGrantId(omnetpp::checked_int_cast<unsigned int>(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'PhyTransmissionInd'", field);
    }
}

const char *PhyTransmissionIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_coord: return omnetpp::opp_typename(typeid(::inet::Coord));
        case FIELD_feedbackReq: return omnetpp::opp_typename(typeid(FeedbackRequest));
        default: return nullptr;
    };
}

omnetpp::any_ptr PhyTransmissionIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        case FIELD_coord: return omnetpp::toAnyPtr(&pp->getCoord()); break;
        case FIELD_grantedBlocks: return omnetpp::toAnyPtr(&pp->getGrantedBlocks()); break;
        case FIELD_feedbackReq: return omnetpp::toAnyPtr(&pp->getFeedbackReq()); break;
        default: return omnetpp::any_ptr(nullptr);
    }
}

void PhyTransmissionIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    PhyTransmissionInd *pp = omnetpp::fromAnyPtr<PhyTransmissionInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'PhyTransmissionInd'", field);
    }
}

Register_Class(SequenceNumberInd)

SequenceNumberInd::SequenceNumberInd() : ::inet::TagBase()
{
}

SequenceNumberInd::SequenceNumberInd(const SequenceNumberInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

SequenceNumberInd::~SequenceNumberInd()
{
}

SequenceNumberInd& SequenceNumberInd::operator=(const SequenceNumberInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void SequenceNumberInd::copy(const SequenceNumberInd& other)
{
    this->sequenceNumber = other.sequenceNumber;
}

void SequenceNumberInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->sequenceNumber);
}

void SequenceNumberInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->sequenceNumber);
}

unsigned int SequenceNumberInd::getSequenceNumber() const
{
    return this->sequenceNumber;
}

void SequenceNumberInd::setSequenceNumber(unsigned int sequenceNumber)
{
    this->sequenceNumber = sequenceNumber;
}

class SequenceNumberIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_sequenceNumber,
    };
  public:
    SequenceNumberIndDescriptor();
    virtual ~SequenceNumberIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(SequenceNumberIndDescriptor)

SequenceNumberIndDescriptor::SequenceNumberIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::SequenceNumberInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

SequenceNumberIndDescriptor::~SequenceNumberIndDescriptor()
{
    delete[] propertyNames;
}

bool SequenceNumberIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<SequenceNumberInd *>(obj)!=nullptr;
}

const char **SequenceNumberIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *SequenceNumberIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string SequenceNumberIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void SequenceNumberIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int SequenceNumberIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 1+base->getFieldCount() : 1;
}

unsigned int SequenceNumberIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_sequenceNumber
    };
    return (field >= 0 && field < 1) ? fieldTypeFlags[field] : 0;
}

const char *SequenceNumberIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "sequenceNumber",
    };
    return (field >= 0 && field < 1) ? fieldNames[field] : nullptr;
}

int SequenceNumberIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "sequenceNumber") == 0) return baseIndex + 0;
    return base ? base->findField(fieldName) : -1;
}

const char *SequenceNumberIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "unsigned int",    // FIELD_sequenceNumber
    };
    return (field >= 0 && field < 1) ? fieldTypeStrings[field] : nullptr;
}

const char **SequenceNumberIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *SequenceNumberIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int SequenceNumberIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void SequenceNumberIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'SequenceNumberInd'", field);
    }
}

const char *SequenceNumberIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string SequenceNumberIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        case FIELD_sequenceNumber: return ulong2string(pp->getSequenceNumber());
        default: return "";
    }
}

void SequenceNumberIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        case FIELD_sequenceNumber: pp->setSequenceNumber(string2ulong(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'SequenceNumberInd'", field);
    }
}

omnetpp::cValue SequenceNumberIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        case FIELD_sequenceNumber: return (omnetpp::intval_t)(pp->getSequenceNumber());
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'SequenceNumberInd' as cValue -- field index out of range?", field);
    }
}

void SequenceNumberIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        case FIELD_sequenceNumber: pp->setSequenceNumber(omnetpp::checked_int_cast<unsigned int>(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'SequenceNumberInd'", field);
    }
}

const char *SequenceNumberIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr SequenceNumberIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void SequenceNumberIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    SequenceNumberInd *pp = omnetpp::fromAnyPtr<SequenceNumberInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'SequenceNumberInd'", field);
    }
}

Register_Class(UserTransmissionParametersInd)

UserTransmissionParametersInd::UserTransmissionParametersInd() : ::inet::TagBase()
{
}

UserTransmissionParametersInd::UserTransmissionParametersInd(const UserTransmissionParametersInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

UserTransmissionParametersInd::~UserTransmissionParametersInd()
{
    delete this->userTxParams;
}

UserTransmissionParametersInd& UserTransmissionParametersInd::operator=(const UserTransmissionParametersInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void UserTransmissionParametersInd::copy(const UserTransmissionParametersInd& other)
{
    delete this->userTxParams;
    this->userTxParams = other.userTxParams;
    if (this->userTxParams != nullptr) {
        this->userTxParams = new UserTxParams(*this->userTxParams);
    }
}

void UserTransmissionParametersInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->userTxParams);
}

void UserTransmissionParametersInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->userTxParams);
}

const UserTxParams * UserTransmissionParametersInd::getUserTxParams() const
{
    return this->userTxParams;
}

void UserTransmissionParametersInd::setUserTxParams(UserTxParams * userTxParams)
{
// cplusplus {{
    // Code inserted at top of setUserTxParams(); allows silent overwrite of earlier object.
    delete this->userTxParams;
    this->userTxParams = nullptr;
// }}
    if (this->userTxParams != nullptr) throw omnetpp::cRuntimeError("setUserTxParams(): a value is already set, remove it first with removeUserTxParams()");
    this->userTxParams = userTxParams;
}

UserTxParams * UserTransmissionParametersInd::removeUserTxParams()
{
    UserTxParams * retval = this->userTxParams;
    this->userTxParams = nullptr;
    return retval;
}

class UserTransmissionParametersIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_userTxParams,
    };
  public:
    UserTransmissionParametersIndDescriptor();
    virtual ~UserTransmissionParametersIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(UserTransmissionParametersIndDescriptor)

UserTransmissionParametersIndDescriptor::UserTransmissionParametersIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::UserTransmissionParametersInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

UserTransmissionParametersIndDescriptor::~UserTransmissionParametersIndDescriptor()
{
    delete[] propertyNames;
}

bool UserTransmissionParametersIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<UserTransmissionParametersInd *>(obj)!=nullptr;
}

const char **UserTransmissionParametersIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *UserTransmissionParametersIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string UserTransmissionParametersIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void UserTransmissionParametersIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int UserTransmissionParametersIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 1+base->getFieldCount() : 1;
}

unsigned int UserTransmissionParametersIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISCOMPOUND | FD_ISPOINTER | FD_ISREPLACEABLE,    // FIELD_userTxParams
    };
    return (field >= 0 && field < 1) ? fieldTypeFlags[field] : 0;
}

const char *UserTransmissionParametersIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "userTxParams",
    };
    return (field >= 0 && field < 1) ? fieldNames[field] : nullptr;
}

int UserTransmissionParametersIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "userTxParams") == 0) return baseIndex + 0;
    return base ? base->findField(fieldName) : -1;
}

const char *UserTransmissionParametersIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "simu5g::UserTxParams",    // FIELD_userTxParams
    };
    return (field >= 0 && field < 1) ? fieldTypeStrings[field] : nullptr;
}

const char **UserTransmissionParametersIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_userTxParams: {
            static const char *names[] = { "owned",  nullptr };
            return names;
        }
        default: return nullptr;
    }
}

const char *UserTransmissionParametersIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_userTxParams:
            if (!strcmp(propertyName, "owned")) return "";
            return nullptr;
        default: return nullptr;
    }
}

int UserTransmissionParametersIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void UserTransmissionParametersIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'UserTransmissionParametersInd'", field);
    }
}

const char *UserTransmissionParametersIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        case FIELD_userTxParams: { const UserTxParams * value = pp->getUserTxParams(); return omnetpp::opp_typename(typeid(*value)); }
        default: return nullptr;
    }
}

std::string UserTransmissionParametersIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        case FIELD_userTxParams: return "";
        default: return "";
    }
}

void UserTransmissionParametersIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'UserTransmissionParametersInd'", field);
    }
}

omnetpp::cValue UserTransmissionParametersIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        case FIELD_userTxParams: return omnetpp::toAnyPtr(pp->getUserTxParams()); break;
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'UserTransmissionParametersInd' as cValue -- field index out of range?", field);
    }
}

void UserTransmissionParametersIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        case FIELD_userTxParams: pp->setUserTxParams(omnetpp::fromAnyPtr<UserTxParams>(value.pointerValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'UserTransmissionParametersInd'", field);
    }
}

const char *UserTransmissionParametersIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_userTxParams: return omnetpp::opp_typename(typeid(UserTxParams));
        default: return nullptr;
    };
}

omnetpp::any_ptr UserTransmissionParametersIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        case FIELD_userTxParams: return omnetpp::toAnyPtr(pp->getUserTxParams()); break;
        default: return omnetpp::any_ptr(nullptr);
    }
}

void UserTransmissionParametersIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    UserTransmissionParametersInd *pp = omnetpp::fromAnyPtr<UserTransmissionParametersInd>(object); (void)pp;
    switch (field) {
        case FIELD_userTxParams: pp->setUserTxParams(omnetpp::fromAnyPtr<UserTxParams>(ptr)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'UserTransmissionParametersInd'", field);
    }
}

Register_Class(PhyReceptionInd)

PhyReceptionInd::PhyReceptionInd() : ::inet::TagBase()
{
}

PhyReceptionInd::PhyReceptionInd(const PhyReceptionInd& other) : ::inet::TagBase(other)
{
    copy(other);
}

PhyReceptionInd::~PhyReceptionInd()
{
}

PhyReceptionInd& PhyReceptionInd::operator=(const PhyReceptionInd& other)
{
    if (this == &other) return *this;
    ::inet::TagBase::operator=(other);
    copy(other);
    return *this;
}

void PhyReceptionInd::copy(const PhyReceptionInd& other)
{
    this->deciderResult = other.deciderResult;
}

void PhyReceptionInd::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::TagBase::parsimPack(b);
    doParsimPacking(b,this->deciderResult);
}

void PhyReceptionInd::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::TagBase::parsimUnpack(b);
    doParsimUnpacking(b,this->deciderResult);
}

bool PhyReceptionInd::getDeciderResult() const
{
    return this->deciderResult;
}

void PhyReceptionInd::setDeciderResult(bool deciderResult)
{
    this->deciderResult = deciderResult;
}

class PhyReceptionIndDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_deciderResult,
    };
  public:
    PhyReceptionIndDescriptor();
    virtual ~PhyReceptionIndDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(PhyReceptionIndDescriptor)

PhyReceptionIndDescriptor::PhyReceptionIndDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::PhyReceptionInd)), "inet::TagBase")
{
    propertyNames = nullptr;
}

PhyReceptionIndDescriptor::~PhyReceptionIndDescriptor()
{
    delete[] propertyNames;
}

bool PhyReceptionIndDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<PhyReceptionInd *>(obj)!=nullptr;
}

const char **PhyReceptionIndDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *PhyReceptionIndDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string PhyReceptionIndDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void PhyReceptionIndDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int PhyReceptionIndDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 1+base->getFieldCount() : 1;
}

unsigned int PhyReceptionIndDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_deciderResult
    };
    return (field >= 0 && field < 1) ? fieldTypeFlags[field] : 0;
}

const char *PhyReceptionIndDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "deciderResult",
    };
    return (field >= 0 && field < 1) ? fieldNames[field] : nullptr;
}

int PhyReceptionIndDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "deciderResult") == 0) return baseIndex + 0;
    return base ? base->findField(fieldName) : -1;
}

const char *PhyReceptionIndDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "bool",    // FIELD_deciderResult
    };
    return (field >= 0 && field < 1) ? fieldTypeStrings[field] : nullptr;
}

const char **PhyReceptionIndDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *PhyReceptionIndDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int PhyReceptionIndDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void PhyReceptionIndDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'PhyReceptionInd'", field);
    }
}

const char *PhyReceptionIndDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string PhyReceptionIndDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        case FIELD_deciderResult: return bool2string(pp->getDeciderResult());
        default: return "";
    }
}

void PhyReceptionIndDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        case FIELD_deciderResult: pp->setDeciderResult(string2bool(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'PhyReceptionInd'", field);
    }
}

omnetpp::cValue PhyReceptionIndDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        case FIELD_deciderResult: return pp->getDeciderResult();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'PhyReceptionInd' as cValue -- field index out of range?", field);
    }
}

void PhyReceptionIndDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        case FIELD_deciderResult: pp->setDeciderResult(value.boolValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'PhyReceptionInd'", field);
    }
}

const char *PhyReceptionIndDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr PhyReceptionIndDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void PhyReceptionIndDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    PhyReceptionInd *pp = omnetpp::fromAnyPtr<PhyReceptionInd>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'PhyReceptionInd'", field);
    }
}

}  // namespace simu5g

namespace omnetpp {

}  // namespace omnetpp

