//
//                  Simu5G
//
// Authors: Giovanni Nardini, Giovanni Stea, Antonio Virdis (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//

#ifndef _LTE_LTEAMC_H_
#define _LTE_LTEAMC_H_

#include "simu5g/common/LteDefs.h"
#include "simu5g/common/cellInfo/CellInfo.h"
#include "simu5g/stack/phy/feedback/LteFeedback.h"
#include "simu5g/stack/phy/feedback/LteSummaryBuffer.h"
#include "simu5g/stack/mac/amc/AmcPilot.h"
#include "simu5g/stack/mac/amc/LteMcs.h"
#include "simu5g/stack/mac/amc/UserTxParams.h"
#include "simu5g/stack/mac/LteMacEnb.h"
#include "simu5g/common/binder/Binder.h"

namespace simu5g {

using namespace omnetpp;

/// Forward declaration of AmcPilot class, used by LteAmc.
class AmcPilot;
/// Forward declaration of CellInfo class, used by LteAmc.
class CellInfo;
/// Forward declaration of LteMacEnb class, used by LteAmc.
class LteMacEnb;

typedef std::map<Remote, std::vector<std::vector<LteSummaryBuffer>>> History_;

/**
 * @class LteAMC
 * @brief Lte AMC module for Omnet++ simulator
 *
 * TODO
 */
class LteAmc
{
  private:
    AmcPilot *getAmcPilot(const cPar& amcMode);
    MacNodeId getNextHop(MacNodeId dst);

  public:
    void printParameters();
    void printFbhb(Direction dir);
    void printTxParams(Direction dir, GHz carrierFrequency);

  protected:
    opp_component_ptr<LteMacEnb> mac_;
    opp_component_ptr<Binder> binder_;
    opp_component_ptr<CellInfo> cellInfo_;
    AmcPilot *pilot_ = nullptr;
    RbAllocationType allocationType_;
    int numBands_;
    MacNodeId nodeId_;
    MacCellId cellId_;
    McsTable dlMcsTable_;
    McsTable ulMcsTable_;
    McsTable d2dMcsTable_;
    double mcsScaleDl_;
    double mcsScaleUl_;
    double mcsScaleD2D_;
    int numAntennas_;
    RemoteSet remoteSet_;
    ConnectedUesMap dlConnectedUe_;
    ConnectedUesMap ulConnectedUe_;
    ConnectedUesMap d2dConnectedUe_;
    std::map<MacNodeId, unsigned int> dlNodeIndex_;
    std::map<MacNodeId, unsigned int> ulNodeIndex_;
    std::map<MacNodeId, unsigned int> d2dNodeIndex_;
    std::vector<MacNodeId> dlRevNodeIndex_;
    std::vector<MacNodeId> ulRevNodeIndex_;
    std::vector<MacNodeId> d2dRevNodeIndex_;

    // one tx param per carrier
    std::map<GHz, std::vector<UserTxParams>> dlTxParams_;
    std::map<GHz, std::vector<UserTxParams>> ulTxParams_;
    std::map<GHz, std::vector<UserTxParams>> d2dTxParams_;

    int fType_; //CQI synchronization Debugging

    // one History per carrier
    std::map<GHz, History_> dlFeedbackHistory_;
    std::map<GHz, History_> ulFeedbackHistory_;
    std::map<GHz, std::map<MacNodeId, History_>> d2dFeedbackHistory_;

    unsigned int fbhbCapacityDl_;
    unsigned int fbhbCapacityUl_;
    unsigned int fbhbCapacityD2D_;
    simtime_t lb_;
    simtime_t ub_;
    double cqiComputationWeight_;

    History_ *getHistory(Direction dir, GHz carrierFrequency);

  public:
    LteAmc(LteMacEnb *mac, Binder *binder, CellInfo *cellInfo, int numAntennas);
    LteAmc(const LteAmc& other) { operator=(other); }
    LteAmc& operator=(const LteAmc& other);
    void initialize();
    virtual ~LteAmc();
    void setfType(int f)
    {
        fType_ = f;
    }

    int getfType()
    {
        return fType_;
    }

    // CodeRate MCS rescaling
    void rescaleMcs(double rePerRb, Direction dir = DL);

    void pushFeedback(MacNodeId id, Direction dir, LteFeedback fb, GHz carrierFrequency);
    void pushFeedbackD2D(MacNodeId id, LteFeedback fb, MacNodeId peerId, GHz carrierFrequency);
    const LteSummaryFeedback& getFeedback(MacNodeId id, Remote antenna, TxMode txMode, const Direction dir, GHz carrierFrequency);
    const LteSummaryFeedback& getFeedbackD2D(MacNodeId id, Remote antenna, TxMode txMode, MacNodeId peerId, GHz carrierFrequency);

    //used when it is necessary to know if the requested feedback exists or not
    // LteSummaryFeedback getFeedback(MacNodeId id, Remote antenna, TxMode txMode, const Direction dir,bool& valid);

    const RemoteSet *getAntennaSet()
    {
        return &remoteSet_;
    }

    bool existTxParams(MacNodeId id, const Direction dir, GHz carrierFrequency);
    const UserTxParams& getTxParams(MacNodeId id, const Direction dir, GHz carrierFrequency);
    const UserTxParams& setTxParams(MacNodeId id, const Direction dir, UserTxParams& info, GHz carrierFrequency);
    const UserTxParams& computeTxParams(MacNodeId id, const Direction dir, GHz carrierFrequency);
    virtual unsigned int computeBitsOnNRbs(MacNodeId id, Band b, unsigned int blocks, const Direction dir, GHz carrierFrequency);
    virtual unsigned int computeBitsOnNRbs(MacNodeId id, Band b, Codeword cw, unsigned int blocks, const Direction dir, GHz carrierFrequency);
    virtual unsigned int computeBytesOnNRbs(MacNodeId id, Band b, unsigned int blocks, const Direction dir, GHz carrierFrequency);
    virtual unsigned int computeBytesOnNRbs(MacNodeId id, Band b, Codeword cw, unsigned int blocks, const Direction dir, GHz carrierFrequency);

    virtual unsigned int computeBitsPerRbBackground(Cqi cqi, const Direction dir, GHz carrierFrequency);

    // multiband version of the above function. It returns the number of bytes that can fit in the given "blocks" of the given "band"
    virtual unsigned int computeBytesOnNRbs_MB(MacNodeId id, Band b, unsigned int blocks, const Direction dir, GHz carrierFrequency);
    virtual unsigned int computeBitsOnNRbs_MB(MacNodeId id, Band b, unsigned int blocks, const Direction dir, GHz carrierFrequency);
    bool setPilotUsableBands(MacNodeId id, UsableBands usableBands);
    UsableBands *getPilotUsableBands(MacNodeId id);

    // utilities - do not involve pilot invocation
    unsigned int getItbsPerCqi(Cqi cqi, const Direction dir);

    /*
     * Access the correct itbs2tbs conversion table given cqi and layer number
     */
    const unsigned int *readTbsVect(Cqi cqi, unsigned int layers, Direction dir);

    /*
     * given <cqi> and <layers> returns bytes allocable in <blocks>
     */
    unsigned int blockGain(Cqi cqi, unsigned int layers, unsigned int blocks, Direction dir);

    /*
     * given <cqi> and <layers> returns blocks capable of carrying  <bytes>
     */
    unsigned int bytesGain(Cqi cqi, unsigned int layers, unsigned int bytes, Direction dir);

    // ---------------------------
    void writeCqiWeight(double weight);
    Cqi readWbCqi(const CqiVector& cqi);
    void detachUser(MacNodeId nodeId, Direction dir);
    void attachUser(MacNodeId nodeId, Direction dir);
    void testUe(MacNodeId nodeId, Direction dir);
    AmcPilot *getPilot() const
    {
        return pilot_;
    }

    CellInfo *getCellInfo()
    {
        return cellInfo_;
    }

    inet::Coord getUePosition(MacNodeId id)
    {
        return cellInfo_->getUePosition(id);
    }

    std::vector<Cqi> readMultiBandCqi(MacNodeId id, const Direction dir, GHz carrierFrequency);

    int getSystemNumBands() { return numBands_; }

    void setPilotMode(PilotComputationModes mode);
};

} //namespace

#endif
