import itertools
import subprocess
import re
from pathlib import Path
import shutil

# =====================================================
# PATHS
# =====================================================

PROJECT = Path("/home/dhruvkhanna/opp_env/HSR_Handover")
INI = PROJECT / "simulations/Railway/omnetpp.ini"

SIM_DIR = PROJECT / "simulations/Railway"

EXE = "../../HSR_Handover"
RESULT_DIR = PROJECT / "simulations/Railway/results/CBR-DL"
EXTRACT_SCRIPT = SIM_DIR / "scripts/extract_results.py"

# =====================================================
# PARAMETERS
# =====================================================

SPEEDS = [
    (500,138.89,36),
    (600,166.67,30),
    (700,194.44,25.7),
    (800,222.22,22.5),
    (900,250.00,20),
    (1000,277.78,18)
]

TTTS = [80,100,128,160,256]

HYS = [2,2.5,3,3.5,4]

# =====================================================
# MODIFY omnetpp.ini
# =====================================================

def update_ini(speed_mps, simtime, ttt, hys):

    txt = INI.read_text()

    txt = re.sub(
        r"sim-time-limit\s*=.*",
        f"sim-time-limit = {simtime}s",
        txt
    )

    txt = re.sub(
        r"\*\.ue\[\*\]\.mobility\.speed\s*=.*",
        f"*.ue[*].mobility.speed = {speed_mps}mps",
        txt
    )

    txt = re.sub(
        r"\*\.ue\[\*\]\.cellularNic\.nrPhy\.timeToTrigger\s*=.*",
        f"*.ue[*].cellularNic.nrPhy.timeToTrigger = {ttt}ms",
        txt
    )

    txt = re.sub(
        r"\*\.ue\[\*\]\.cellularNic\.nrPhy\.hysteresis\s*=.*",
        f"*.ue[*].cellularNic.nrPhy.hysteresis = {hys}dB",
        txt
    )

    INI.write_text(txt)

# =====================================================
# RUN SIMULATION
# =====================================================

def run_simulation():
    shutil.rmtree(RESULT_DIR, ignore_errors=True)
    RESULT_DIR.mkdir(parents=True, exist_ok=True)

    cmd = [
        EXE,
        "-u","Cmdenv",
        "-c","CBR-DL",
        "-n","../..:../../../inet-4.6.0/examples:../../../inet-4.6.0/showcases:../../../inet-4.6.0/src:../../../inet-4.6.0/tests/validation:../../../inet-4.6.0/tests/networks:../../../inet-4.6.0/tutorials:../../../simu5g-1.4.3/emulation:../../../simu5g-1.4.3/simulations:../../../simu5g-1.4.3/src",
        "-x","inet.emulation;inet.showcases.visualizer.osg;inet.examples.emulation;inet.showcases.emulation;inet.validation.tsn;inet.visualizer.osg;simu5g.simulations.nr.cars;simu5g.simulations.lte.cars",
        "--image-path=../../../inet-4.6.0/images:../../../simu5g-1.4.3/images",
        "-l","../../../inet-4.6.0/src/INET",
        "-l","../../../simu5g-1.4.3/src/simu5g",
        "omnetpp.ini"
    ]

    subprocess.run(
        cmd,
        cwd=SIM_DIR,
        check=True
    )

# =====================================================
# RUN EXTRACTION
# =====================================================

def run_extract(speed,ttt,hys):

    subprocess.run([
        "python3",
        str(EXTRACT_SCRIPT),
        str(speed),
        str(ttt),
        str(hys)
    ])

# =====================================================
# MAIN LOOP
# =====================================================

count = 1

for speed, speed_mps, simtime in SPEEDS:

    for ttt in TTTS:

        for hys in HYS:

            print("="*60)
            print(f"Simulation {count}/150")
            print(f"Speed={speed}, TTT={ttt}, HYS={hys}")
            print("="*60)

            update_ini(speed_mps, simtime, ttt, hys)
            
            print("--------------------------------")
            print(speed, ttt, hys)
            
            for line in INI.read_text().splitlines():
                if ("timeToTrigger" in line or
                    "hysteresis" in line or
                    "mobility.speed" in line or
                    "sim-time-limit" in line):
                    print(line)
            
            print("--------------------------------")

            run_simulation()

            run_extract(speed, ttt, hys)

            count += 1