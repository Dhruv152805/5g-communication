//
// Generated file, do not edit! Created by opp_msgtool 6.4 from simu5g/stack/compManager/compManagerProportional/X2CompProportionalRequestIE.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#if defined(__clang__)
#  pragma clang diagnostic ignored "-Wshadow"
#  pragma clang diagnostic ignored "-Wconversion"
#  pragma clang diagnostic ignored "-Wunused-parameter"
#  pragma clang diagnostic ignored "-Wc++98-compat"
#  pragma clang diagnostic ignored "-Wunreachable-code-break"
#  pragma clang diagnostic ignored "-Wold-style-cast"
#elif defined(__GNUC__)
#  pragma GCC diagnostic ignored "-Wshadow"
#  pragma GCC diagnostic ignored "-Wconversion"
#  pragma GCC diagnostic ignored "-Wunused-parameter"
#  pragma GCC diagnostic ignored "-Wold-style-cast"
#  pragma GCC diagnostic ignored "-Wsuggest-attribute=noreturn"
#  pragma GCC diagnostic ignored "-Wfloat-conversion"
#endif

#include <iostream>
#include <sstream>
#include <memory>
#include <type_traits>
#include "X2CompProportionalRequestIE_m.h"

namespace omnetpp {

// Template pack/unpack rules. They are declared *after* a1l type-specific pack functions for multiple reasons.
// They are in the omnetpp namespace, to allow them to be found by argument-dependent lookup via the cCommBuffer argument

// Packing/unpacking an std::vector
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::vector<T,A>& v)
{
    int n = v.size();
    doParsimPacking(buffer, n);
    for (int i = 0; i < n; i++)
        doParsimPacking(buffer, v[i]);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::vector<T,A>& v)
{
    int n;
    doParsimUnpacking(buffer, n);
    v.resize(n);
    for (int i = 0; i < n; i++)
        doParsimUnpacking(buffer, v[i]);
}

// Packing/unpacking an std::list
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::list<T,A>& l)
{
    doParsimPacking(buffer, (int)l.size());
    for (typename std::list<T,A>::const_iterator it = l.begin(); it != l.end(); ++it)
        doParsimPacking(buffer, (T&)*it);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::list<T,A>& l)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        l.push_back(T());
        doParsimUnpacking(buffer, l.back());
    }
}

// Packing/unpacking an std::set
template<typename T, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::set<T,Tr,A>& s)
{
    doParsimPacking(buffer, (int)s.size());
    for (typename std::set<T,Tr,A>::const_iterator it = s.begin(); it != s.end(); ++it)
        doParsimPacking(buffer, *it);
}

template<typename T, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::set<T,Tr,A>& s)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        T x;
        doParsimUnpacking(buffer, x);
        s.insert(x);
    }
}

// Packing/unpacking an std::map
template<typename K, typename V, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::map<K,V,Tr,A>& m)
{
    doParsimPacking(buffer, (int)m.size());
    for (typename std::map<K,V,Tr,A>::const_iterator it = m.begin(); it != m.end(); ++it) {
        doParsimPacking(buffer, it->first);
        doParsimPacking(buffer, it->second);
    }
}

template<typename K, typename V, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::map<K,V,Tr,A>& m)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        K k; V v;
        doParsimUnpacking(buffer, k);
        doParsimUnpacking(buffer, v);
        m[k] = v;
    }
}

// Default pack/unpack function for arrays
template<typename T>
void doParsimArrayPacking(omnetpp::cCommBuffer *b, const T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimPacking(b, t[i]);
}

template<typename T>
void doParsimArrayUnpacking(omnetpp::cCommBuffer *b, T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimUnpacking(b, t[i]);
}

// Default rule to prevent compiler from choosing base class' doParsimPacking() function
template<typename T>
void doParsimPacking(omnetpp::cCommBuffer *, const T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimPacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

template<typename T>
void doParsimUnpacking(omnetpp::cCommBuffer *, T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimUnpacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

}  // namespace omnetpp


template<typename T>
std::string toStringIfPrintable(const T& t) {
    if constexpr (omnetpp::internal::is_printable<T>::value) {
        std::ostringstream os;
        os << t;
        return os.str();
    }
    return omnetpp::cClassDescriptor::UNPRINTABLE;
}

template<typename T>
bool fromStringIfExtractable(T& t, const char *s) {
    if constexpr (omnetpp::internal::is_extractable<T>::value) {
        std::istringstream is(s);
        is >> t;
        return true;
    }
    return false;
}

namespace simu5g {

Register_Class(X2CompProportionalRequestIE)

X2CompProportionalRequestIE::X2CompProportionalRequestIE() : ::simu5g::X2CompRequestIE()
{
    this->setType(COMP_PROP_REQUEST_IE);
    this->setLength(sizeof(uint32_t));

}

X2CompProportionalRequestIE::X2CompProportionalRequestIE(const X2CompProportionalRequestIE& other) : ::simu5g::X2CompRequestIE(other)
{
    copy(other);
}

X2CompProportionalRequestIE::~X2CompProportionalRequestIE()
{
}

X2CompProportionalRequestIE& X2CompProportionalRequestIE::operator=(const X2CompProportionalRequestIE& other)
{
    if (this == &other) return *this;
    ::simu5g::X2CompRequestIE::operator=(other);
    copy(other);
    return *this;
}

void X2CompProportionalRequestIE::copy(const X2CompProportionalRequestIE& other)
{
    this->numBlocks = other.numBlocks;
}

void X2CompProportionalRequestIE::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::simu5g::X2CompRequestIE::parsimPack(b);
    doParsimPacking(b,this->numBlocks);
}

void X2CompProportionalRequestIE::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::simu5g::X2CompRequestIE::parsimUnpack(b);
    doParsimUnpacking(b,this->numBlocks);
}

uint32_t X2CompProportionalRequestIE::getNumBlocks() const
{
    return this->numBlocks;
}

void X2CompProportionalRequestIE::setNumBlocks(uint32_t numBlocks)
{
    this->numBlocks = numBlocks;
}

class X2CompProportionalRequestIEDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_numBlocks,
    };
  public:
    X2CompProportionalRequestIEDescriptor();
    virtual ~X2CompProportionalRequestIEDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual std::string getValueAsString(omnetpp::any_ptr object) const override;
    virtual void setValueAsString(omnetpp::any_ptr object, const char *value) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(X2CompProportionalRequestIEDescriptor)

X2CompProportionalRequestIEDescriptor::X2CompProportionalRequestIEDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(simu5g::X2CompProportionalRequestIE)), "simu5g::X2CompRequestIE")
{
    propertyNames = nullptr;
}

X2CompProportionalRequestIEDescriptor::~X2CompProportionalRequestIEDescriptor()
{
    delete[] propertyNames;
}

bool X2CompProportionalRequestIEDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<X2CompProportionalRequestIE *>(obj)!=nullptr;
}

const char **X2CompProportionalRequestIEDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *X2CompProportionalRequestIEDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

std::string X2CompProportionalRequestIEDescriptor::getValueAsString(omnetpp::any_ptr object) const
{
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    return ((cObject*)pp)->str();
}

void X2CompProportionalRequestIEDescriptor::setValueAsString(omnetpp::any_ptr object, const char *value) const
{
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    if (!fromStringIfExtractable(*pp, value))
        cClassDescriptor::setValueAsString(object, value);
}

int X2CompProportionalRequestIEDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 1+base->getFieldCount() : 1;
}

unsigned int X2CompProportionalRequestIEDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_numBlocks
    };
    return (field >= 0 && field < 1) ? fieldTypeFlags[field] : 0;
}

const char *X2CompProportionalRequestIEDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "numBlocks",
    };
    return (field >= 0 && field < 1) ? fieldNames[field] : nullptr;
}

int X2CompProportionalRequestIEDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "numBlocks") == 0) return baseIndex + 0;
    return base ? base->findField(fieldName) : -1;
}

const char *X2CompProportionalRequestIEDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "uint32_t",    // FIELD_numBlocks
    };
    return (field >= 0 && field < 1) ? fieldTypeStrings[field] : nullptr;
}

const char **X2CompProportionalRequestIEDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *X2CompProportionalRequestIEDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int X2CompProportionalRequestIEDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void X2CompProportionalRequestIEDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'X2CompProportionalRequestIE'", field);
    }
}

const char *X2CompProportionalRequestIEDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string X2CompProportionalRequestIEDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        case FIELD_numBlocks: return ulong2string(pp->getNumBlocks());
        default: return "";
    }
}

void X2CompProportionalRequestIEDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        case FIELD_numBlocks: pp->setNumBlocks(string2ulong(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'X2CompProportionalRequestIE'", field);
    }
}

omnetpp::cValue X2CompProportionalRequestIEDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        case FIELD_numBlocks: return (omnetpp::intval_t)(pp->getNumBlocks());
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'X2CompProportionalRequestIE' as cValue -- field index out of range?", field);
    }
}

void X2CompProportionalRequestIEDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        case FIELD_numBlocks: pp->setNumBlocks(omnetpp::checked_int_cast<uint32_t>(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'X2CompProportionalRequestIE'", field);
    }
}

const char *X2CompProportionalRequestIEDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr X2CompProportionalRequestIEDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void X2CompProportionalRequestIEDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    X2CompProportionalRequestIE *pp = omnetpp::fromAnyPtr<X2CompProportionalRequestIE>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'X2CompProportionalRequestIE'", field);
    }
}

}  // namespace simu5g

namespace omnetpp {

}  // namespace omnetpp

