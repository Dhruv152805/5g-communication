import os
import re
import csv
import sys
import bisect

SPEED = float(sys.argv[1])
TTT = float(sys.argv[2])
HYS = float(sys.argv[3])

RESULT_DIR = "/home/dhruvkhanna/opp_env/HSR_Handover/simulations/Railway/results/CBR-DL"

vec_files = [f for f in sorted(os.listdir(RESULT_DIR)) if f.endswith(".vec")]
vec_file = max(vec_files, key=lambda f: os.path.getmtime(os.path.join(RESULT_DIR, f))) if vec_files else None
if vec_file is None:
    print("No .vec file found.")
    exit()

# ============================================================
# Parse VEC — collect raw (time, value) pairs per metric
# ============================================================

wanted = {
    "rlcThroughputDl": "Throughput",
    "rlcPacketLossDl": "Packet Loss",
    "rcvdSinrDl": "SINR",
    "rsrp": "RSRP",
    "rsrq": "RSRQ",
    "servingCell": "ServingCell",
    "previousServingCell": "PreviousServingCell",
    "handoverSuccess": "HO Success",
    "pingPong": "Ping-Pong",
    "outage": "Outage",
    "reconnect": "Reconnect",
    "handoverDelay": "HO Delay",
    "handoverFailure": "HO Failure",
}

vector_ids = {}
from collections import defaultdict

series = defaultdict(list)  # name -> list of (time, value)

with open(os.path.join(RESULT_DIR, vec_file), "r", errors="ignore") as f:
    for line in f:
        if line.startswith("vector"):
            parts = line.split()
            vecid = parts[1]
            modulePath = parts[2]
            m = re.search(r'ue\[(\d+)\]', modulePath)
            if not m:
                continue
            ue = int(m.group(1))
            name = parts[-2].replace(":vector", "")
            # Only take vectors from this UE's own modules (skip the 10 duplicate gNB-side copies)
            if "ue[" not in modulePath:
                continue
            for key, label in wanted.items():
                if key in name:
                    vector_ids[vecid] = (ue,label)
        elif re.match(r'^\d+', line):
            parts = line.split()
            vecid = parts[0]
            if vecid in vector_ids:
                try:
                    t = float(parts[-2])
                    v = float(parts[-1])
                    ue, metric = vector_ids[vecid]
                    series[(ue, metric)].append((t, v))
                except (ValueError, IndexError):
                    pass

for name in series:
    series[name].sort(key=lambda p: p[0])

# ============================================================
# Build per-ms grid from RSRP timestamps (periodic every 1ms)
# ============================================================

def forward_fill_lookup(ue,name):
    """Return a function that, given time t, returns the last known value at/before t."""
    times = [p[0] for p in series[(ue, name)]]
    values = [p[1] for p in series[(ue, name)]]
    def lookup(t):
        idx = bisect.bisect_right(times, t) - 1
        return values[idx] if idx >= 0 else ""
    return lookup

def exact_lookup(ue,name, default=""):
    """Return a function mapping time -> value only at the exact ms the event/sample occurred."""
    d = {}
    for t, v in series[(ue, name)]:
        d[round(t, 3)] = v  # round to nearest ms to match the grid
    return lambda t: d.get(round(t, 3), default)


# ============================================================
# Write per-ms CSV
# ============================================================

out_dir = "/mnt/c/Users/IIST PC-9/Desktop/IIST Dhruv"
csv_file = os.path.join(out_dir, f"timeseries_speed{SPEED}_ttt{TTT}_hys{HYS}.csv")

header = ["Time(ms)", "UE","Speed", "TTT", "HYS", "ServingCell","PreviousServingCell", "RSRP", "RSRQ", "SINR",
          "Throughput", "PacketLoss", "HO Success", "HO Failure", "Ping-Pong",
          "Outage", "Reconnect", "HO Delay"]
rows_written = 0

with open(csv_file, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(header)


    for ue in range(20):
        grid_times = sorted(set(t for t, v in series[(ue, "RSRP")]))
        if not grid_times:
            continue
        if (ue, "ServingCell") not in series:
            continue
        rsrp_at = exact_lookup(ue, "RSRP")
        rsrq_at = exact_lookup(ue, "RSRQ")
        throughput_at = forward_fill_lookup(ue, "Throughput")
        packetloss_at = forward_fill_lookup(ue, "Packet Loss")
        sinr_at = forward_fill_lookup(ue, "SINR")
        servingcell_at = forward_fill_lookup(ue, "ServingCell")
        previouscell_at = forward_fill_lookup(ue, "PreviousServingCell")
        ho_success_at = exact_lookup(ue, "HO Success", 0)
        ho_failure_at = exact_lookup(ue, "HO Failure", 0)
        pingpong_at = exact_lookup(ue, "Ping-Pong", 0)
        outage_at = exact_lookup(ue, "Outage", 0)
        reconnect_at = exact_lookup(ue, "Reconnect", 0)
        ho_delay_at = exact_lookup(ue, "HO Delay", 0)
        for t in grid_times:
            writer.writerow([
                int(round(t*1000)), ue, SPEED, TTT, HYS,
                servingcell_at(t),
                previouscell_at(t),
                rsrp_at(t),
                rsrq_at(t),
                sinr_at(t),
                throughput_at(t),
                packetloss_at(t),
                ho_success_at(t),
                ho_failure_at(t),
                pingpong_at(t),
                outage_at(t),
                reconnect_at(t),
                ho_delay_at(t),
            ])
            
            rows_written += 1

print(f"\nExtraction Complete! {rows_written} rows written.")
print(f"Results saved to {csv_file}")