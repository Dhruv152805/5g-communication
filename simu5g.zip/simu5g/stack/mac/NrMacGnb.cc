//
//                  Simu5G
//
// Authors: Giovanni Nardini, Giovanni Stea, Antonio Virdis (University of Pisa)
//
// This file is part of a software released under the license included in file
// "license.pdf". Please read LICENSE and README files before using it.
// The above files and the present reference are part of the software itself,
// and cannot be removed from it.
//
#include "simu5g/stack/mac/NrMacGnb.h"
#include "simu5g/stack/mac/scheduler/NrSchedulerGnbUl.h"

namespace simu5g {

Define_Module(NrMacGnb);

NrMacGnb::NrMacGnb() : LteMacEnbD2D()
{
    isNr_ = true;
}


void NrMacGnb::initialize(int stage)
{
    if (stage == INITSTAGE_SIMU5G_MAC_SCHEDULER_CREATION) {
        // Create and initialize NR MAC Uplink scheduler
        if (enbSchedulerUl_ == nullptr) {
            enbSchedulerUl_ = new NrSchedulerGnbUl();
            enbSchedulerUl_->resourceBlocks() = cellInfo_->getNumBands();
            enbSchedulerUl_->initialize(UL, this, binder_);
        }
    }
    LteMacEnbD2D::initialize(stage);
}

} //namespace

